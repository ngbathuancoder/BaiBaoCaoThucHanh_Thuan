void main() {
    unsigned char i;

    do {

        for (i = 0; i < 32; i++) {
            if (i < 8) {
                P0 = ~(1 << i);
                P1 = 0xFF;
                P2 = 0xFF;
                P3 = 0xFF;
            }
            else if (i < 16) {
                P0 = 0xFF;
                P1 = ~(1 << (i - 8));
                P2 = 0xFF;
                P3 = 0xFF;
            }
            else if (i < 24) {
                P0 = 0xFF;
                P1 = 0xFF;
                P2 = ~(1 << (i - 16));
                P3 = 0xFF;
            }
            else {
                P0 = 0xFF;
                P1 = 0xFF;
                P2 = 0xFF;
                P3 = ~(1 << (i - 24));
            }

            Delay_ms(200);
        }

        P0 = 0xFF;
        P1 = 0xFF;
        P2 = 0xFF;
        P3 = 0xFF;
        Delay_ms(200);

    } while(1);
}