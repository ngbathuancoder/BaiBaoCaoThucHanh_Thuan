unsigned short kp, index = 0; // Bi?n luu m� ph�m b?m v� v? tr� nh?p
char hex1[5], hex2[5];  // Hai s? hexa nh?p v�o
unsigned int num1 = 0, num2 = 0, sum = 0, product = 0; // C�c bi?n s?

char keypadPort at P0;  // K?t n?i c?ng keypad

// K?t n?i LCD
sbit LCD_RS at P2_0_bit;
sbit LCD_EN at P2_1_bit;
sbit LCD_D4 at P2_2_bit;
sbit LCD_D5 at P2_3_bit;
sbit LCD_D6 at P2_4_bit;
sbit LCD_D7 at P2_5_bit;

// H�m chuy?n d?i chu?i hexa sang s? nguy�n
unsigned int HexToDec(char *hexStr) {
    unsigned int result = 0;
    char *ptr = hexStr;
    while (*ptr) {
        result <<= 4; // D?ch tr�i 4 bit (nh�n 16)
        if (*ptr >= '0' && *ptr <= '9') {
            result += *ptr - '0';
        } else if (*ptr >= 'A' && *ptr <= 'F') {
            result += *ptr - 'A' + 10;
        }
        ptr++;
    }
    return result;
}

void main() {
    Lcd_Init();          // Kh?i t?o LCD
    Lcd_Cmd(_LCD_CLEAR); // X�a m�n h�nh
    Lcd_Cmd(_LCD_CURSOR_OFF); // T?t con tr? tr�n LCD
    Keypad_Init();       // Kh?i t?o keypad

    // Hi?n th? hu?ng d?n nh?p li?u ban d?u
    Lcd_Out(1, 1, "So1: ");
    Lcd_Out(2, 1, "So2: ");

    while (1) {
        kp = 0;
        // �?i nh?n ph�m
        do {
            kp = Keypad_Key_Click();
        } while (!kp);

        // Chuy?n m� ph�m th�nh k� t? ASCII
        switch (kp) {
            case 1: kp = '1'; break;
            case 2: kp = '2'; break;
            case 3: kp = '3'; break;
            case 4: kp = 'A'; break;
            case 5: kp = '4'; break;
            case 6: kp = '5'; break;
            case 7: kp = '6'; break;
            case 8: kp = 'B'; break;
            case 9: kp = '7'; break;
            case 10: kp = '8'; break;
            case 11: kp = '9'; break;
            case 12: kp = 'C'; break;
            case 13: kp = '*'; break; // B? qua n?u nh?n '*'
            case 14: kp = '0'; break;
            case 15: kp = '#'; break; // X�c nh?n nh?p
            case 16: kp = 'D'; break;
        }

        if (kp == '#') { // X�c nh?n ho�n th�nh nh?p s?
            if (index == 0) { // Nh?p xong s? th? nh?t
                num1 = HexToDec(hex1); // Chuy?n d?i hexa sang s?
                index = 1;              // Chuy?n sang nh?p s? th? hai
                Lcd_Out(1, 1, "So1: ");
                Lcd_Out(2, 1, "So2: ");
            } else if (index == 1) { // Nh?p xong s? th? hai
                num2 = HexToDec(hex2); // Chuy?n d?i hexa sang s?
                sum = num1 + num2;     // T�nh t?ng
                product = num1 * num2; // T�nh t�ch

                // Hi?n th? k?t qu?
                Lcd_Cmd(_LCD_CLEAR);
                Lcd_Out(1, 1, "TONG: ");
                WordToHex(sum, hex1);   // Chuy?n t?ng sang chu?i hexa
                Lcd_Out(1, 6, hex1);

                Lcd_Out(2, 1, "TICH: ");
                WordToHex(product, hex2); // Chuy?n t�ch sang chu?i hexa
                Lcd_Out(2, 6, hex2);

                while (1); // D?ng chuong tr�nh
            }
        } else if (kp != '*') { // Th�m k� t? v�o s? hexa
            if (index == 0 && strlen(hex1) < 4) { // Nh?p s? th? nh?t
                hex1[strlen(hex1)] = kp;
                hex1[strlen(hex1) + 1] = '\0'; // K?t th�c chu?i
                Lcd_Chr(1, 7 + strlen(hex1), kp);
            } else if (index == 1 && strlen(hex2) < 4) { // Nh?p s? th? hai
                hex2[strlen(hex2)] = kp;
                hex2[strlen(hex2) + 1] = '\0'; // K?t th�c chu?i
                Lcd_Chr(2, 7 + strlen(hex2), kp);
            }
        }
    }
}
