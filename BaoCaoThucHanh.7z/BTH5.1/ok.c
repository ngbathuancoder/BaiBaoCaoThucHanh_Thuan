#include <REGX52.H>
#define LED P0

unsigned char MALED[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
int i, count;
unsigned char count0, count1;  // Declare count0 and count1

void delay(int ms)
{
    unsigned int x, y;
    for(x = 0; x < ms; x++)
    {
        for(y = 0; y < 125; y++)
        {
        }
    }
}

void hienthi()
{
    count0 = count / 10;  // Tens place
    count1 = count % 10;  // Ones place
    
    for(i = 0; i < 50; i++)
    {
        LED = MALED[count0];   // Display tens place
        P2_0 = 0;
        delay(5);
        P2_0 = 1;
    
        LED = MALED[count1];   // Display ones place
        P2_1 = 0;
        delay(5);
        P2_1 = 1;
    
        LED = MALED[count0];   // Display tens place again
        P2_2 = 0;
        delay(5);
        P2_2 = 1;
    
        LED = MALED[count1];   // Display ones place again
        P2_3 = 0;
        delay(5);
        P2_3 = 1;
    }
}

void main()
{
    EX0 = 1;
    EX1 = 1;
    IT0 = 1;
    IT1 = 1;
    EA = 1;
    
    while(1)
    {
        hienthi();
    }
}

void Ngat_0(void) interrupt 0
{
    count++;
    if(count > 99)
    {
        count = 0;
    }
}
