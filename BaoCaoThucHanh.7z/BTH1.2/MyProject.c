// C?u h�nh th?i gian delay 500ms
#define DELAY_MS 500

// D? li?u bitmap c?a k� t? T, H, U, A, N (�� ch?nh s?a th? t? h�ng)
unsigned char THUAN[5][8] = {
    {0x00, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7E}, // T
    {0x00, 0x66, 0x66, 0x66, 0x7E, 0x66, 0x66, 0x66}, // H
    {0x00, 0x3C, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66}, // U
    {0x00, 0x66, 0x66, 0x66, 0x7E, 0x66, 0x66, 0x3C}, // A
    {0x00, 0x66, 0x66, 0x66, 0x6E, 0x7E, 0x76, 0x66}  // N
};

// H�m delay ms
void delay_ms(unsigned int time) {
    unsigned int i, j;
    for (i = 0; i < time; i++)
        for (j = 0; j < 127; j++);
}

// Hi?n th? t?ng k� t?
void display_char(unsigned char *char_data) {
    unsigned char row, col;
    for (col = 0; col < 8; col++) {
        P2 = ~(1 << (7 - col));   // Ch?n c?t (gi?m m?c logic v� d?o c?t)
        P3 = char_data[col];      // G?i d? li?u h�ng
        delay_ms(1);              // Qu�t nhanh t?ng c?t
        P2 = 0xFF;                // T?t c?t
    }
}

// H�m ch�nh
void main() {
    unsigned char i;
    while (1) {
        for (i = 0; i < 5; i++) { // Duy?t t?ng k� t? trong "THUAN"
            unsigned int t;
            for (t = 0; t < (DELAY_MS / 8); t++) { // Hi?n th? k� t? trong 500ms
                display_char(THUAN[i]);
            }
        }
    }
}
