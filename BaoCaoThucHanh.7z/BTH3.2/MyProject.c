unsigned short shifter = 1, digits_array_index = 0;
unsigned int digit, count, phut = 0, giay = 0;
unsigned short digits_array[4]; // 4 LED 7 thanh
unsigned int mask[10] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};

 void Timer0InterruptHandler() org IVT_ADDR_ET0
 {
  TR0_bit = 0;
  TH0 = 0xFC;
  TL0 = 0x18;
  TR0_bit = 1;
  count++;

  if(count%2==0)
  {
  P0=0XFF;
  P0 = digits_array[digits_array_index];
  P1 = shifter;
  shifter <<= 1;
   if (shifter > 8)
    shifter = 1;
  digits_array_index++;
   if (digits_array_index > 3)
  digits_array_index = 0;
  }

  if(count==1000)
  {
  count = 0;
  giay++;
  if(giay==60)
  {
   phut++;
   giay = 0;
   if(phut==60) phut = 0;
  }
 digit = phut/10u;
 digits_array[3] = mask[digit];
 digit = phut % 10u;
 digits_array[2] = mask[digit];
 digit = giay / 10u;
 digits_array[1] = mask[digit];
 digit = giay % 10u;
 digits_array[0] = mask[digit];
 }
}

 void main () {
 TMOD = 0x01;
 TH0 = 0xFC;
 TL0 = 0x18;
 IE = 0x82;
 TR0_bit = 1;

 digit = phut/10u;
 digits_array[3] = mask[digit];
 digit = phut % 10u;
 digits_array[2] = mask[digit];
 digit = giay /10u;
 digits_array[1] = mask[digit];
 digit = giay % 10u;
 digits_array[0] = mask[digit];

 while(1);
}
