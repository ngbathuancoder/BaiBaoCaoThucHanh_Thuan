#include <REGX52.H>

// �?nh nghia ch�n di?u khi?n LED 7 do?n v� d�n giao th�ng
#define LED P0          // LED 7 thanh k?t n?i v?i Port 0
sbit RED = P2^4;        // ��n d? n?i v?i P2.4
sbit YELLOW = P2^5;     // ��n v�ng n?i v?i P2.5
sbit GREEN = P2^6;      // ��n xanh n?i v?i P2.6
sbit BUTTON = P3^0;     // N�t nh?n n?i v?i P3.0

// M� hi?n th? cho LED 7 thanh (Common Cathode)
unsigned char SEGMENT_CODE[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};

// H�m delay co b?n
void delay(unsigned int time) {
    unsigned int i, j;
    for (i = 0; i < time; i++) {
        for (j = 0; j < 120; j++); // Kho?ng 1ms
    }
}

// Hi?n th? s? l�n LED 7 do?n (Qu�t t?ng LED)
void displayNumber(unsigned char number, unsigned int time) {
    unsigned int t;
    for (t = 0; t < time; t++) {
        // Hi?n th? h�ng ch?c
        LED = SEGMENT_CODE[number / 10];
        P2_0 = 0;   // Ch?n LED th? nh?t
        delay(5);
        P2_0 = 1;   // T?t LED th? nh?t

        // Hi?n th? h�ng don v?
        LED = SEGMENT_CODE[number % 10];
        P2_1 = 0;   // Ch?n LED th? hai
        delay(5);
        P2_1 = 1;   // T?t LED th? hai
    }
}

// H�m ch?y d�n giao th�ng
void TrafficLight() {
    unsigned char i;

    // 1. ��n d? s�ng 25 gi�y
    RED = 0;
    for (i = 25; i > 0; i--) {
        displayNumber(i, 100);  // Hi?n th? s? d?m ngu?c
    }
    RED = 1; // T?t d�n d?

    // 2. ��n v�ng s�ng 3 gi�y
    YELLOW = 0;
    for (i = 3; i > 0; i--) {
        displayNumber(i, 100);  // Hi?n th? s? d?m ngu?c
    }
    YELLOW = 1; // T?t d�n v�ng

    
		// 3. ��n xanh s�ng 25 gi�y
    GREEN = 0; RED = 1; YELLOW = 1; // B?t d�n xanh
    for (i = 25; i > 0; i--) {
        displayNumber(i, 100);  // Hi?n th? s? d?m ngu?c (100 l?n qu�t ~ 1 gi�y)
    }
    GREEN = 1; // T?t d�n xanh
}

void main() {
    // Kh?i t?o ban d?u
    LED = 0xFF;    // T?t LED 7 thanh
    RED = 1;       // T?t d�n d?
    YELLOW = 1;    // T?t d�n v�ng
    GREEN = 1;     // T?t d�n xanh

    while (1) {
        if (BUTTON == 0) {     // Ki?m tra n�t nh?n
            delay(20);         // Ch?ng d?i ph�m
            if (BUTTON == 0) {
                TrafficLight(); // Ch?y d�n giao th�ng
            }
        }
    }
}
