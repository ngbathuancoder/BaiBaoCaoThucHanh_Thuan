// Khai b�o ch�n k?t n?i
sbit LED_RED at P2_0;    // ��n �?
sbit LED_YELLOW at P2_1; // ��n V�NG
sbit LED_GREEN at P2_2;  // ��n XANH

unsigned char seg_code[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
// M� 7 thanh d? hi?n th? 0-9 (Common Cathode)

// H�m delay don gi?n
void delay(unsigned int time) {
    unsigned int i, j;
    for(i = 0; i < time; i++)
      for(j = 0; j < 1275; j++);
}

// H�m hi?n th? s? tr�n LED 7 thanh
void display7Segment(unsigned char number) {
    P0 = seg_code[number]; // P0 k?t n?i LED 7 thanh
}

// H�m di?u khi?n d�n giao th�ng
void trafficLight() {
    unsigned char i;

    // ��n �? (10 gi�y)
    LED_RED = 1; LED_YELLOW = 0; LED_GREEN = 0;
    for(i = 10; i > 0; i--) {
        display7Segment(i); // Hi?n th? d?m ngu?c
        delay(1000);        // 1 gi�y
    }
    LED_RED = 0;

    // ��n XANH (10 gi�y)
    LED_GREEN = 1;
    for(i = 10; i > 0; i--) {
        display7Segment(i);
        delay(1000);
    }
    LED_GREEN = 0;

    // ��n V�NG (5 gi�y)
    LED_YELLOW = 1;
    for(i = 5; i > 0; i--) {
        display7Segment(i);
        delay(1000);
    }
    LED_YELLOW = 0;
}

void main() {
    P0 = 0x00; // Port 0 xu?t d? li?u cho LED 7 thanh
    P2 = 0x00; // Port 2 di?u khi?n d�n giao th�ng

    while(1) {
        trafficLight(); // G?i h�m di?u khi?n d�n giao th�ng
    }
}
